"""Version information."""

__version__ = "4.7.1+rocm62.gfx1010"
