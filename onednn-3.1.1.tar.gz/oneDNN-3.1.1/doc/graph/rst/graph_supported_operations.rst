Supported Operations
####################

The complete operation set is defined at
`specification <https://spec.oneapi.io/onednn-graph/latest/ops/index.html>`__.
Here only a subset of operation set is implemented.
