Performance Profiling and Inspection
########################################

.. toctree::
   :maxdepth: 1

   dev_guide_verbose
   dev_guide_performance_settings
   dev_guide_benchdnn
   dev_guide_profilers
   dev_guide_inspecting_jit
   page_performance_profiling_cpp
   dev_guide_cpu_dispatcher_control
   dev_guide_cpu_isa_hints
   