This code is from [Intel(R) Instrumentation and Tracing Technology (ITT) and
Just-In-Time (JIT) API](https://github.com/intel/ittapi)

tag: 3.22.5
